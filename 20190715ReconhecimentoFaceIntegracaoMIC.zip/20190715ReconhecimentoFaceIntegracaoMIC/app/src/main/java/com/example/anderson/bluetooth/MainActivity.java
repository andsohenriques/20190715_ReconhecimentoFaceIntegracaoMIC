package com.example.anderson.bluetooth;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.bluetooth.BluetoothAdapter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    Button btnConexao, btnDescobrir;
    private TextView vozTexto;

    private static final int SOLICITA_ATIVACAO = 1;
    private static final int SOLICITA_CONEXAO = 2;
    private static final int SOLICITA_DESCOBERTA_BT = 3;
    private static final int MESSAGE_READ = 4;

    ConnectedThread connectedThread;

    Handler mHandler;
    StringBuilder dadosBluetooth = new StringBuilder();

    BluetoothAdapter meuBluetoothAdapter = null;
    BluetoothDevice meuDevice = null;
    BluetoothSocket meuSocket = null;

    boolean conexao = false;

    private static String MAC = null;

    UUID MEU_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
    //voz
    private Button openMic;
    private final int REQ_CODE_SPEECH_OUTPUT = 143;
    String comando, comandoVoz;
    //voz
    public TextToSpeech toSpeech;
    int result;
    //textoVoz

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnConexao = (Button)findViewById(R.id.btnConexao);
        btnDescobrir = (Button)findViewById(R.id.btnDescobrir);
        openMic = (Button)findViewById(R.id.btnVoz);
        vozTexto = (TextView)findViewById(R.id.textView);



        meuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (meuBluetoothAdapter == null) {
            // Device does not support Bluetooth
            Toast.makeText(getApplicationContext(),"Seu Dispositivo não possui Bluetooth",Toast.LENGTH_LONG).show();
        } else if(!((BluetoothAdapter) meuBluetoothAdapter).isEnabled()){
                    Intent ativaBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(ativaBluetooth, SOLICITA_ATIVACAO);

                }

        btnConexao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (conexao){
                    //desconectar
                    try{
                        meuSocket.close();
                        conexao = false;
                        btnConexao.setText("CONECTAR");
                        Toast.makeText(getApplicationContext(),"Bluetooth foi Desconectado!",Toast.LENGTH_LONG).show();
                    } catch (IOException erro){
                        Toast.makeText(getApplicationContext(),"Ocorreu um erro: "+erro,Toast.LENGTH_LONG).show();
                    }
                } else {
                    //conectar
                    Intent abreLista=new Intent(MainActivity.this,ListaDispositivos.class);
                    startActivityForResult(abreLista,SOLICITA_CONEXAO);
                }

            }
        });

        btnDescobrir.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (!meuBluetoothAdapter.isDiscovering()){
                    Toast.makeText(getApplicationContext(),"Descobrindo Dispositivos!",Toast.LENGTH_LONG).show();
                    Intent listarNovosDevices = new Intent(MainActivity.this, DescobrindoDispositivos.class);
                    startActivityForResult(listarNovosDevices,SOLICITA_DESCOBERTA_BT);
                }
            }
        });

        openMic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (conexao){
                    btnVoz();

                    //connectedThread.enviar("A\r\n");
                    //connectedThread.enviar("a\r\n");
                } else{

                    Toast.makeText(getApplicationContext(),"Bluetooth não está conectado!",Toast.LENGTH_LONG).show();
                }
            }
        });

        toSpeech=new TextToSpeech(MainActivity.this, new TextToSpeech.OnInitListener(){
            @Override
            public void onInit(int status) {
                if (status==TextToSpeech.SUCCESS)
                {
                    result=toSpeech.setLanguage(Locale.getDefault());
                    //toSpeech.setPitch(1f);
                    //toSpeech.setSpeechRate(2f);
                    /*Voice voiceobj = new Voice("it-it-x-kda#male_2-local",
                            Locale.getDefault(), 1, 1, false, null);

                    toSpeech.setVoice(voiceobj);*/

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Caracteristica não suportada", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mHandler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if (msg.what==MESSAGE_READ){
                    String recebidos = (String) msg.obj;
                    dadosBluetooth.append(recebidos);
                    //int fimInformacao=dadosBluetooth.indexOf("\n");
                    int fimInformacao=dadosBluetooth.indexOf("\r");
                    if (fimInformacao>0){
                        String dadoNumeroMIC = dadosBluetooth.substring(0,fimInformacao);
                        int tamInformacao = dadoNumeroMIC.length();
                        if (dadoNumeroMIC.contains("r")){
                        //if (dadosBluetooth.charAt(0)!='A'){
                            String identMIC = dadosBluetooth.substring(0,tamInformacao);
                            Log.d("Recebidos", identMIC);
                            ///iniciar escuta do locutor///
                            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                            //intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Hill Speak Now ...");
                            toSpeech.speak("Hello so I can recognize you, please stay at a distance of 50cm.", TextToSpeech.QUEUE_FLUSH,null);
                            toSpeech.speak("I am the vision of the future, would you like to dialogue?", TextToSpeech.QUEUE_FLUSH,null);
                            try {
                                startActivityForResult(intent, REQ_CODE_SPEECH_OUTPUT);
                            }
                            catch (ActivityNotFoundException tim) {
                            //just put an toast if Google mic is not opened
                            }
                            ///finaliza escuta locutor///


                            /*
                            if (dadosFinais.contains("L1on")){
                                btnLed1.setText("Led 1 LIGADO");
                                Log.d("Led1","Ligado");
                            }else if (dadosFinais.contains("L1of")){
                                btnLed1.setText("Led 1 DESLIGADO");
                                Log.d("Led1","Desligado");
                            }
                            */

                        }
                        dadosBluetooth.delete(0,dadosBluetooth.length());

                    }
                }

            }
        };

    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if (toSpeech!=null)
        {
            toSpeech.stop();
            toSpeech.shutdown();
        }
    }

    private void btnVoz (){
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Hill Speak Now ...");

        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_OUTPUT);
        }
        catch (ActivityNotFoundException tim) {
//just put an toast if Google mic is not opened
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case SOLICITA_ATIVACAO:
                if(resultCode== Activity.RESULT_OK){
                    Toast.makeText(getApplicationContext(),"O Bluetooth foi ativado!",Toast.LENGTH_LONG).show();
                } else{
                    Toast.makeText(getApplicationContext(),"O Bluetooth não foi ativado, o APP será encerrado!",Toast.LENGTH_LONG).show();
                    finish();
                }
                break;

            case SOLICITA_CONEXAO:
                if(resultCode== Activity.RESULT_OK){
                    MAC = data.getExtras().getString(ListaDispositivos.ENDERECO_MAC);
                    Toast.makeText(getApplicationContext(),"MAC Final: "+MAC,Toast.LENGTH_LONG).show();
                    meuDevice = meuBluetoothAdapter.getRemoteDevice(MAC);
                    try{
                        meuSocket = meuDevice.createRfcommSocketToServiceRecord(MEU_UUID);
                        meuSocket.connect();
                        Toast.makeText(getApplicationContext(),"Você foi conectado com: "+MAC,Toast.LENGTH_LONG).show();

                        conexao = true;
                        connectedThread = new ConnectedThread(meuSocket);
                        connectedThread.start();
                        btnConexao.setText("DESCONECTAR");

                    } catch (IOException erro){
                        conexao = false;
                        Toast.makeText(getApplicationContext(),"Ocorreu um erro: "+erro,Toast.LENGTH_LONG).show();
                    }
                } else{
                    Toast.makeText(getApplicationContext(),"Falha ao obter o MAC!",Toast.LENGTH_LONG).show();
                }
                break;

            case REQ_CODE_SPEECH_OUTPUT: {
                if ((resultCode == RESULT_OK) && (null!= data)){
                    ArrayList<String> voiceInText = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    comandoVoz = voiceInText.get(0);
                    vozTexto.setText(comandoVoz);
                    //Toast.makeText(getApplicationContext(),"Comando = "+vozTexto.toString(),Toast.LENGTH_LONG).show();


                    ///Incluir aqui seu código para reconhecimento facial///

                    ///Finalização com variável string das informações do reconhecimento facial


                    ////////comandos manuais/////////
                    if (comandoVoz.contains("foward right")) {
                            comando = "A\r\n";
                        }
                    else if (comandoVoz.contains("foward")) {
                        comando = "B\r\n";
                        toSpeech.speak("Beware the Robot is moving forward, you can use the Stop or Behind", TextToSpeech.QUEUE_FLUSH,null,null);
                        }
                        else if (comandoVoz.contains("foward left")) {
                            comando = "C\r\n";
                            }
                            else if (comandoVoz.contains("left")) {
                                comando = "D\r\n";
                                }
                                else if (comandoVoz.contains("right")) {
                                   comando = "E\r\n";
                                    }
                                    else if (comandoVoz.contains("behind left")) {
                                        comando = "F\r\n";
                                        }
                                        else if (comandoVoz.contains("behind")) {
                                            comando = "G\r\n";
                                            toSpeech.speak("Be aware the robot is behind", TextToSpeech.QUEUE_FLUSH,null,null);
                                            toSpeech.speak("We have other modes of movement: clockwise, anticlockwise, in doubt send the Stop command", TextToSpeech.QUEUE_FLUSH,null);
                                            }
                                            else if (comandoVoz.contains("behind right")) {
                                                comando = "H\r\n";
                                                }
                                                else if (comandoVoz.contains("clock-wise"){//)&&(!(comandoVoz.contains("anti")))) {
                                                    comando = "I\r\n";
                                                    toSpeech.speak("If I do not stop, I'll go dizzy.", TextToSpeech.QUEUE_FLUSH,null,null);
                                                    }
                                                    else if (comandoVoz.contains("anticlock-wise")) {
                                                        comando = "J\r\n";
                                                        toSpeech.speak("I get dizzy very easily", TextToSpeech.QUEUE_FLUSH,null);
                                                        }
                                                        else if (comandoVoz.contains("run oracle protocol")) {
                                                            toSpeech.speak("Now it's party reason, get ready!", TextToSpeech.QUEUE_FLUSH,null,null);
                                                            comando = "I\r\nJ\r\nJ\r\nI\r\nJ\r\nI\r\n";
                                                            }
                                                            else {
                                                                    comando = "a\r\n";
                                                            }
                    connectedThread.enviar(comando);
                    Toast.makeText(getApplicationContext(),"Comando = "+comando,Toast.LENGTH_LONG).show();
                    }
                ////////comandos manuais/////////


                }



        }

    }

    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[1024];  // buffer store for the stream
            int bytes; // bytes returned from read()

            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {
                    // Read from the InputStream
                    bytes = mmInStream.read(buffer);

                    String dadosBt = new String(buffer, 0, bytes);
                    // Send the obtained bytes to the UI activity
                    mHandler.obtainMessage(MESSAGE_READ, bytes, -1, dadosBt).sendToTarget();
                } catch (IOException e) {
                    break;
                }
            }
        }

        public void enviar(String dadosEnviar) {
            byte [] msgBuffer = dadosEnviar.getBytes();
            try {
                mmOutStream.write(msgBuffer);
            } catch (IOException e) { }
        }

    }


}
